require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const multer = require("multer");
const QRCode = require("qrcode");
const OpenAI = require("openai");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { maxHttpBufferSize: 8e6 });
const PORT = Number(process.env.PORT || 3000);
const DATA_DIR = path.join(__dirname, "data");
const UPLOAD_DIR = path.join(__dirname, "uploads");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, "store.json");
const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = /\.(pdf|txt|md|docx|pptx)$/i.test(file.originalname);
    cb(allowed ? null : new Error("รองรับไฟล์ PDF, TXT, MD, DOCX และ PPTX เท่านั้น"), allowed);
  }
});

const defaultStore = {
  plans: [], groups: [], exams: [], resources: [], simulations: [], checkins: [],
  chat: [], profiles: [], scoreModels: [
    { id: "kku-custom", name: "คำนวณคะแนนแบบกำหนดเอง (ตรวจสอบประกาศก่อนใช้)", year: "กำหนดเอง", faculty: "", program: "", subjects: [] }
  ]
};
function loadStore() {
  try { return { ...structuredClone(defaultStore), ...JSON.parse(fs.readFileSync(DB_FILE, "utf8")) }; }
  catch { return structuredClone(defaultStore); }
}
let store = loadStore();
let saveQueue = Promise.resolve();
function saveStore() {
  saveQueue = saveQueue.then(() => fs.promises.writeFile(DB_FILE, JSON.stringify(store, null, 2)));
  return saveQueue;
}
function id() { return crypto.randomUUID(); }
function cleanText(v, max = 2000) { return String(v ?? "").trim().slice(0, max); }
function publicGroup(g) {
  return { id: g.id, name: g.name, description: g.description, isPrivate: !!g.isPrivate, inviteCode: g.inviteCode, createdBy: g.createdBy, createdAt: g.createdAt };
}
function adminOk(req) {
  const configured = process.env.ADMIN_PASSCODE;
  return !!configured && req.headers["x-admin-passcode"] === configured;
}
function safeUser(v) {
  return { userId: cleanText(v.userId, 100), nickname: cleanText(v.nickname, 40) || "นักอ่าน", joinedAt: Date.now() };
}
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.get("/api/health", (_req, res) => res.json({ ok: true, openaiConfigured: !!process.env.OPENAI_API_KEY, model: process.env.OPENAI_MODEL || "gpt-4.1-mini" }));
app.get("/api/state", (_req, res) => {
  res.json({
    plans: store.plans, groups: store.groups.map(publicGroup), exams: store.exams,
    resources: store.resources, simulations: store.simulations, checkins: store.checkins,
    chat: store.chat.slice(-150), scoreModels: store.scoreModels
  });
});

app.post("/api/profile", async (req, res) => {
  const profile = safeUser(req.body || {});
  if (!profile.userId) return res.status(400).json({ error: "ไม่พบรหัสผู้ใช้" });
  const existing = store.profiles.find(p => p.userId === profile.userId);
  if (existing) existing.nickname = profile.nickname;
  else store.profiles.push(profile);
  await saveStore();
  res.json({ ok: true, profile });
});

app.post("/api/plans", async (req, res) => {
  const p = req.body || {};
  if (!p.userId || !p.title) return res.status(400).json({ error: "กรอกชื่อแผนและผู้ใช้ก่อน" });
  const item = { id: id(), userId: cleanText(p.userId, 100), title: cleanText(p.title, 180), subject: cleanText(p.subject, 80), target: cleanText(p.target, 180), date: cleanText(p.date, 30), minutes: Math.max(0, Number(p.minutes || 0)), progress: 0, notes: cleanText(p.notes, 1000), createdAt: Date.now() };
  store.plans.push(item); await saveStore(); res.json(item);
});
app.patch("/api/plans/:id", async (req, res) => {
  const p = store.plans.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "ไม่พบแผน" });
  if (req.body.progress !== undefined) p.progress = Math.max(0, Math.min(100, Number(req.body.progress) || 0));
  if (req.body.done !== undefined) p.done = !!req.body.done;
  if (req.body.notes !== undefined) p.notes = cleanText(req.body.notes, 1000);
  await saveStore(); res.json(p);
});
app.delete("/api/plans/:id", async (req, res) => {
  store.plans = store.plans.filter(x => x.id !== req.params.id); await saveStore(); res.json({ ok: true });
});

app.post("/api/groups", async (req, res) => {
  const b = req.body || {};
  if (!b.name || !b.userId) return res.status(400).json({ error: "กรอกชื่อกลุ่มและผู้สร้าง" });
  const group = { id: id(), name: cleanText(b.name, 100), description: cleanText(b.description, 300), isPrivate: !!b.isPrivate, inviteCode: crypto.randomBytes(5).toString("hex"), createdBy: cleanText(b.userId, 100), createdAt: Date.now() };
  store.groups.push(group); await saveStore(); res.json(publicGroup(group));
});
app.get("/api/groups/:code/invite", async (req, res) => {
  const group = store.groups.find(g => g.id === req.params.code || g.inviteCode === req.params.code);
  if (!group) return res.status(404).json({ error: "ไม่พบกลุ่ม" });
  const url = `${req.protocol}://${req.get("host")}/?join=${encodeURIComponent(group.inviteCode)}`;
  try { res.json({ url, qr: await QRCode.toDataURL(url, { width: 240, margin: 1 }), group: publicGroup(group) }); }
  catch { res.json({ url, group: publicGroup(group) }); }
});
app.post("/api/groups/join", async (req, res) => {
  const code = cleanText(req.body.code, 100);
  const group = store.groups.find(g => g.inviteCode === code || g.id === code);
  if (!group) return res.status(404).json({ error: "ลิงก์หรือรหัสเชิญไม่ถูกต้อง" });
  res.json(publicGroup(group));
});

app.post("/api/checkins", async (req, res) => {
  const b = req.body || {};
  const item = { id: id(), userId: cleanText(b.userId, 100), planId: cleanText(b.planId, 100), subject: cleanText(b.subject, 80), chapter: cleanText(b.chapter, 180), minutes: Math.max(0, Math.min(1440, Number(b.minutes) || 0)), correct: Math.max(0, Number(b.correct) || 0), total: Math.max(0, Number(b.total) || 0), note: cleanText(b.note, 1000), createdAt: Date.now() };
  if (!item.userId) return res.status(400).json({ error: "ไม่พบผู้ใช้" });
  store.checkins.push(item);
  if (item.planId) {
    const p = store.plans.find(x => x.id === item.planId);
    if (p) p.progress = Math.min(100, (Number(p.progress) || 0) + (item.total > 0 ? Math.round((item.correct / item.total) * 10) : 5));
  }
  await saveStore(); io.emit("progress:update", item); res.json(item);
});

app.post("/api/exams", async (req, res) => {
  const b = req.body || {};
  if (!b.title || !b.subject) return res.status(400).json({ error: "กรอกชื่อชุดข้อสอบและวิชา" });
  const item = { id: id(), title: cleanText(b.title, 180), subject: cleanText(b.subject, 80), chapter: cleanText(b.chapter, 100), description: cleanText(b.description, 1000), questions: Array.isArray(b.questions) ? b.questions.slice(0, 100).map(q => ({ question: cleanText(q.question, 1000), choices: (q.choices || []).slice(0, 5).map(x => cleanText(x, 300)), answer: Math.max(0, Number(q.answer) || 0), explanation: cleanText(q.explanation, 1000) })) : [], createdBy: cleanText(b.createdBy, 100), createdAt: Date.now() };
  store.exams.push(item); await saveStore(); res.json(item);
});

app.post("/api/score-models", async (req, res) => {
  if (!adminOk(req)) return res.status(403).json({ error: "ต้องใช้รหัสผู้ควบคุมที่ตั้งไว้ในไฟล์ .env" });
  const b = req.body || {};
  if (!b.name || !Array.isArray(b.subjects) || !b.subjects.length) return res.status(400).json({ error: "ใส่ชื่อสูตรและอย่างน้อยหนึ่งวิชา" });
  const subjects = b.subjects.map(s => ({ name: cleanText(s.name, 80), weight: Math.max(0, Number(s.weight) || 0), max: Math.max(1, Number(s.max) || 100) }));
  const item = { id: id(), name: cleanText(b.name, 180), year: cleanText(b.year, 40), faculty: cleanText(b.faculty, 120), program: cleanText(b.program, 120), referenceUrl: cleanText(b.referenceUrl, 500), note: cleanText(b.note, 1000), subjects, updatedAt: Date.now() };
  store.scoreModels.push(item); await saveStore(); res.json(item);
});
app.post("/api/resources", async (req, res) => {
  if (!adminOk(req)) return res.status(403).json({ error: "ต้องใช้รหัสผู้ควบคุมที่ตั้งไว้ในไฟล์ .env" });
  const b = req.body || {};
  if (!b.title || !b.url) return res.status(400).json({ error: "กรอกชื่อและลิงก์ไฟล์/หนังสือ" });
  const item = { id: id(), title: cleanText(b.title, 180), type: ["ebook", "simulation"].includes(b.type) ? b.type : "ebook", subject: cleanText(b.subject, 80), url: cleanText(b.url, 1000), description: cleanText(b.description, 1000), createdAt: Date.now() };
  (item.type === "simulation" ? store.simulations : store.resources).push(item);
  await saveStore(); res.json(item);
});
app.post("/api/admin/upload", upload.single("file"), async (req, res) => {
  if (!adminOk(req)) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(403).json({ error: "ต้องใช้รหัสผู้ควบคุมที่ตั้งไว้ในไฟล์ .env" });
  }
  if (!req.file) return res.status(400).json({ error: "เลือกไฟล์ก่อน" });
  const safeName = `${Date.now()}-${req.file.originalname.replace(/[^a-zA-Z0-9ก-๙._-]/g, "_")}`;
  const dest = path.join(UPLOAD_DIR, safeName);
  fs.renameSync(req.file.path, dest);
  const item = { id: id(), title: cleanText(req.body.title || req.file.originalname, 180), type: req.body.type === "simulation" ? "simulation" : "ebook", subject: cleanText(req.body.subject, 80), url: `/uploads/${encodeURIComponent(safeName)}`, description: cleanText(req.body.description, 1000), createdAt: Date.now() };
  (item.type === "simulation" ? store.simulations : store.resources).push(item);
  await saveStore(); res.json(item);
});
app.use("/uploads", express.static(UPLOAD_DIR, { setHeaders: (res) => res.setHeader("X-Content-Type-Options", "nosniff") }));

app.post("/api/ai/summarize", upload.single("file"), async (req, res) => {
  if (!process.env.OPENAI_API_KEY) {
    if (req.file) fs.unlink(req.file.path, () => {});
    return res.status(503).json({ error: "ยังไม่ได้ตั้ง OPENAI_API_KEY ในไฟล์ .env" });
  }
  if (!req.file) return res.status(400).json({ error: "เลือกไฟล์บทเรียนก่อน" });
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  let uploadedId = null;
  try {
    const uploaded = await client.files.create({
      file: fs.createReadStream(req.file.path),
      purpose: "user_data"
    });
    uploadedId = uploaded.id;
    const instructions = `คุณเป็นติวเตอร์เตรียมสอบ NETSAT ภาษาไทย อธิบายตามเนื้อหาในไฟล์ ห้ามแต่งข้อมูลที่ไม่มีในเอกสาร หากส่วนใดไม่ชัดเจนให้บอกว่าไม่พบในไฟล์ สร้างผลลัพธ์เป็นภาษาไทยโดยมีหัวข้อ: 1) สรุปภาพรวม 2) แนวคิด/สูตร/คำจำกัดความสำคัญ 3) ตารางจำง่าย 4) จุดที่มักสับสน 5) ตัวอย่างพร้อมวิธีคิด 6) แบบทดสอบทบทวน 10 ข้อพร้อมเฉลยท้ายสุด แยกเนื้อหาที่อ้างจากไฟล์กับคำอธิบายเสริมให้ชัดเจน`;
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions,
      input: [{
        role: "user",
        content: [
          { type: "input_file", file_id: uploadedId },
          { type: "input_text", text: `วิชา: ${cleanText(req.body.subject, 80) || "ไม่ระบุ"}\nบทเรียน/เป้าหมาย: ${cleanText(req.body.topic, 300) || "สรุปเพื่อเตรียมสอบ NETSAT"}\nระดับความละเอียด: ${cleanText(req.body.depth, 50) || "ละเอียดสำหรับทบทวนสอบ"}\nโปรดใช้หัวข้อและรูปแบบที่อ่านง่าย` }
        ]
      }]
    });
    res.json({ summary: response.output_text || "โมเดลไม่ส่งข้อความกลับมา", model: process.env.OPENAI_MODEL || "gpt-4.1-mini" });
  } catch (err) {
    res.status(500).json({ error: `สรุปไม่สำเร็จ: ${cleanText(err.message, 500)}` });
  } finally {
    if (req.file) fs.unlink(req.file.path, () => {});
    // Uploaded OpenAI file is retained in the API account unless explicitly deleted.
    if (uploadedId) client.files.delete(uploadedId).catch(() => {});
  }
});

const liveUsers = new Map(); // socket.id -> { userId, nickname, room, startedAt }
const activeSessions = new Map(); // userId -> { userId, nickname, room, startedAt }
io.on("connection", socket => {
  socket.on("profile:set", async payload => {
    const u = safeUser(payload || {});
    if (!u.userId) return;
    socket.data.user = u;
    liveUsers.set(socket.id, { ...u, room: "lobby", startedAt: Date.now() });
    socket.join("lobby");
    io.emit("presence:update", getPresence());
  });
  socket.on("room:join", ({ roomId } = {}) => {
    const u = socket.data.user;
    if (!u) return;
    const room = cleanText(roomId, 100) || "lobby";
    for (const r of socket.rooms) if (r !== socket.id) socket.leave(r);
    socket.join(room);
    const info = liveUsers.get(socket.id) || { ...u, startedAt: Date.now() };
    info.room = room; liveUsers.set(socket.id, info);
    activeSessions.set(u.userId, { userId: u.userId, nickname: u.nickname, room, startedAt: Date.now() });
    io.emit("presence:update", getPresence());
    io.to(room).emit("room:system", { text: `${u.nickname} เข้าห้องแล้ว`, at: Date.now() });
  });
  socket.on("room:leave", () => {
    const u = socket.data.user;
    if (!u) return;
    const info = liveUsers.get(socket.id);
    if (info) { socket.leave(info.room); liveUsers.delete(socket.id); }
    activeSessions.delete(u.userId);
    io.emit("presence:update", getPresence());
  });
  socket.on("chat:send", async ({ text: msg, roomId } = {}) => {
    const u = socket.data.user;
    const message = cleanText(msg, 1000);
    if (!u || !message) return;
    const item = { id: id(), userId: u.userId, nickname: u.nickname, text: message, roomId: cleanText(roomId, 100) || "lobby", at: Date.now() };
    store.chat.push(item); store.chat = store.chat.slice(-500); await saveStore();
    io.to(item.roomId).emit("chat:message", item);
  });
  socket.on("disconnect", () => {
    const u = socket.data.user;
    liveUsers.delete(socket.id);
    if (u && ![...liveUsers.values()].some(x => x.userId === u.userId)) activeSessions.delete(u.userId);
    io.emit("presence:update", getPresence());
  });
});
function getPresence() {
  const users = [...liveUsers.values()];
  const now = Date.now();
  return {
    users: users.map(u => ({ userId: u.userId, nickname: u.nickname, room: u.room, minutes: Math.floor((now - u.startedAt) / 60000) })),
    rooms: [...new Set(users.map(u => u.room))].map(room => ({ room, count: users.filter(u => u.room === room).length })),
    totalMinutes: users.reduce((sum, u) => sum + Math.floor((now - u.startedAt) / 60000), 0)
  };
}

app.use((err, _req, res, _next) => {
  res.status(400).json({ error: cleanText(err.message || "เกิดข้อผิดพลาด", 500) });
});
server.listen(PORT, "0.0.0.0", () => console.log(`NETSAT Prep Hub running at http://localhost:${PORT}`));
