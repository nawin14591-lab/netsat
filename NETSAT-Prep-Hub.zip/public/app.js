(() => {
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const params = new URLSearchParams(location.search);
  const randomId = () => "u-" + (crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).slice(2));
  let userId = localStorage.getItem("netsat_user_id") || randomId();
  localStorage.setItem("netsat_user_id", userId);
  let nickname = localStorage.getItem("netsat_nickname") || "";
  let state = { plans: [], groups: [], exams: [], resources: [], simulations: [], checkins: [], chat: [], scoreModels: [] };
  let socket = null, currentRoom = "lobby", summaryText = "", activeQuiz = null, quizAnswers = {};
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
  const dateFmt = v => v ? new Date(v).toLocaleDateString("th-TH",{day:"numeric",month:"short",year:"2-digit"}) : "ไม่กำหนดวัน";
  const timeFmt = v => new Date(v).toLocaleTimeString("th-TH",{hour:"2-digit",minute:"2-digit"});
  function toast(msg) { const t=$("#toast"); t.textContent=msg; t.classList.add("show"); setTimeout(()=>t.classList.remove("show"),3200); }
  async function api(url, options={}) {
    const r = await fetch(url, options);
    const data = await r.json().catch(()=>({}));
    if (!r.ok) throw new Error(data.error || "เกิดข้อผิดพลาด");
    return data;
  }
  const json = data => ({ method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(data) });
  async function refresh() {
    state = await api("/api/state");
    renderAll();
  }
  function setPage(page) {
    $$(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+page));
    $$(".nav").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
    window.scrollTo({top:0,behavior:"smooth"});
  }
  $$(".nav").forEach(b=>b.addEventListener("click",()=>setPage(b.dataset.page)));
  $$("[data-goto]").forEach(b=>b.addEventListener("click",()=>setPage(b.dataset.goto)));
  function showProfile(force=false) {
    $("#profileModal").classList.toggle("open",force || !nickname);
    $("#profileForm").elements.nickname.value=nickname;
  }
  $("#editProfile").addEventListener("click",()=>showProfile(true));
  $("#profileForm").addEventListener("submit",async e=>{
    e.preventDefault(); nickname=$("#profileForm").elements.nickname.value.trim() || "นักอ่าน";
    localStorage.setItem("netsat_nickname",nickname);
    await api("/api/profile",json({userId,nickname})); $("#profileModal").classList.remove("open");
    if(socket) socket.emit("profile:set",{userId,nickname});
    toast("บันทึกชื่อเล่นแล้ว");
  });
  async function init() {
    if(!nickname) showProfile(true);
    try {
      await api("/api/profile",json({userId,nickname:nickname||"นักอ่าน"}));
      const health=await api("/api/health");
      $("#connection").textContent="เซิร์ฟเวอร์ออนไลน์";
      if(!health.openaiConfigured) $("#summaryResult").innerHTML='<div class="empty">ยังไม่ได้ตั้งค่า OpenAI API key — เพิ่ม OPENAI_API_KEY ในไฟล์ .env แล้วเริ่มเซิร์ฟเวอร์ใหม่</div>';
      socket=io();
      socket.on("connect",()=>{ $("#connection").textContent="ออนไลน์ · เรียลไทม์"; $("#chatConnection").textContent="เชื่อมต่อแล้ว"; socket.emit("profile:set",{userId,nickname:nickname||"นักอ่าน"}); socket.emit("room:join",{roomId:currentRoom}); });
      socket.on("disconnect",()=>{ $("#connection").textContent="ขาดการเชื่อมต่อ"; $("#chatConnection").textContent="ออฟไลน์"; });
      socket.on("presence:update",renderPresence);
      socket.on("chat:message",msg=>{ if(msg.roomId===currentRoom){ appendMessage(msg); } });
      socket.on("room:system",msg=>{ if(currentRoom!=="lobby") appendMessage({nickname:"ระบบ",text:msg.text,at:msg.at,system:true}); });
      socket.on("progress:update",()=>refresh().catch(()=>{}));
    } catch(e) { $("#connection").textContent="เซิร์ฟเวอร์ยังไม่พร้อม"; toast(e.message); }
    await refresh().catch(e=>toast(e.message));
    if(params.get("join")) { $("#joinCode").value=params.get("join"); setPage("rooms"); joinGroup(params.get("join")); }
  }
  function renderAll() {
    renderDashboard(); renderPlans(); renderGroups(); renderExams(); renderProgress(); renderChatHistory(); renderResources(); renderScoreModels();
  }
  function renderDashboard() {
    const mine=state.plans.filter(p=>p.userId===userId);
    const minutes=state.checkins.filter(c=>c.userId===userId).reduce((a,c)=>a+c.minutes,0);
    const done=mine.filter(p=>p.done||p.progress>=100).length;
    $("#stats").innerHTML=[
      ["เป้าหมายของฉัน",mine.length,"แผนอ่านหนังสือ","▤"],
      ["เวลาอ่านสะสม",Math.floor(minutes/60)+" ชม.","จากเช็กอินของคุณ","◷"],
      ["ทำสำเร็จ",done,"เป้าหมายที่เสร็จแล้ว","✓"],
      ["ชุดข้อสอบ",state.exams.length,"ในคลังส่วนกลาง","▦"]
    ].map(x=>`<div class="stat"><div class="stat-top"><span>${x[0]}</span><span class="stat-icon">${x[3]}</span></div><strong>${x[1]}</strong><small>${x[2]}</small></div>`).join("");
    $("#dashboardPlans").innerHTML=mine.slice(0,4).map(planCard).join("")||'<div class="empty">ยังไม่มีแผน เริ่มสร้างเป้าหมายแรกของคุณได้เลย</div>';
    $("#dashboardLive").innerHTML='<div class="item"><b>◉ ห้องกลาง</b><p>เปิดห้องเพื่ออ่านพร้อมเพื่อนและดูจำนวนผู้ใช้งานที่ออนไลน์</p><button class="secondary small-btn" data-join-lobby>เข้าห้องอ่านรวม</button></div>'+state.groups.slice(0,2).map(g=>`<div class="item"><b>${esc(g.name)}</b><p>${esc(g.description||"กลุ่มอ่านหนังสือ")}</p><button class="secondary small-btn" data-join="${g.id}">เข้ากลุ่ม</button></div>`).join("");
    $$("[data-join-lobby]").forEach(b=>b.onclick=()=>joinRoom("lobby","ห้องกลาง"));
    $$("[data-join]").forEach(b=>b.onclick=()=>{const g=state.groups.find(x=>x.id===b.dataset.join);if(g)joinRoom(g.id,g.name)});
  }
  function planCard(p) {
    return `<div class="item"><div class="item-head"><div><h3>${esc(p.title)}</h3><p>${esc(p.subject)} · ${esc(p.target||"ยังไม่ระบุคณะ")}</p><div class="meta">${dateFmt(p.date)} · วางแผน ${p.minutes} นาที</div></div><label class="small"><input type="checkbox" data-done="${p.id}" ${p.done?"checked":""}> เสร็จ</label></div><div class="progress-track"><div class="progress-fill" style="width:${p.done?100:(p.progress||0)}%"></div></div><div class="item-head"><span class="meta">ความคืบหน้า ${p.done?100:(p.progress||0)}%</span><button class="text-btn" data-delete-plan="${p.id}">ลบ</button></div></div>`;
  }
  function renderPlans() {
    const mine=state.plans.filter(p=>p.userId===userId);
    $("#plansList").innerHTML=mine.map(planCard).join("")||'<div class="empty">ยังไม่มีแผนอ่านหนังสือ</div>';
    $("#planCount").textContent=mine.length+" รายการ";
    $("#checkinPlan").innerHTML='<option value="">ไม่ผูกกับแผน</option>'+mine.map(p=>`<option value="${p.id}">${esc(p.title)}</option>`).join("");
    $$("[data-done]").forEach(c=>c.onchange=async()=>{await api("/api/plans/"+c.dataset.done,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({done:c.checked,progress:c.checked?100:0})});await refresh()});
    $$("[data-delete-plan]").forEach(b=>b.onclick=async()=>{if(confirm("ลบแผนนี้หรือไม่?")){await api("/api/plans/"+b.dataset.deletePlan,{method:"DELETE"});await refresh()}});
  }
  $("#planForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api("/api/plans",json({userId,title:f.get("title"),subject:f.get("subject"),date:f.get("date"),target:f.get("target"),minutes:f.get("minutes"),notes:f.get("notes")}));e.currentTarget.reset();await refresh();toast("เพิ่มแผนแล้ว")}catch(err){toast(err.message)}});
  $("#groupForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{const g=await api("/api/groups",json({userId,name:f.get("name"),description:f.get("description"),isPrivate:f.get("isPrivate")==="on"}));await refresh();await showInvite(g.id);toast("สร้างกลุ่มแล้ว")}catch(err){toast(err.message)}});
  async function showInvite(id) {
    const x=await api("/api/groups/"+id+"/invite");
    $("#inviteBox").innerHTML=`<div class="item"><b>ลิงก์เชิญ: ${esc(x.group.name)}</b><p><a class="resource-link" href="${esc(x.url)}">${esc(x.url)}</a></p><div class="grid two"><button class="secondary" id="copyInvite">คัดลอกลิงก์</button><button class="secondary" id="shareInvite">แชร์ลิงก์</button></div>${x.qr?`<p><img alt="QR เชิญเข้ากลุ่ม" width="180" height="180" src="${x.qr}"></p>`:""}<span class="meta">รหัสเชิญ: ${esc(x.group.inviteCode)}</span></div>`;
    $("#copyInvite").onclick=()=>navigator.clipboard.writeText(x.url).then(()=>toast("คัดลอกแล้ว")).catch(()=>toast(x.url));
    $("#shareInvite").onclick=()=>navigator.share?navigator.share({title:x.group.name,url:x.url}):navigator.clipboard.writeText(x.url).then(()=>toast("คัดลอกลิงก์แล้ว"));
  }
  async function joinGroup(code) {
    try {const g=await api("/api/groups/join",json({code}));await joinRoom(g.id,g.name);toast("เข้ากลุ่ม "+g.name+" แล้ว");}
    catch(e){toast(e.message)}
  }
  $("#joinByCode").onclick=()=>joinGroup($("#joinCode").value.trim());
  $("#joinLobby").onclick=()=>joinRoom("lobby","ห้องกลาง");
  async function joinRoom(id,name) {
    currentRoom=id; if(socket)socket.emit("room:join",{roomId:id});
    $("#currentRoom").textContent="ห้องปัจจุบัน: "+name;$("#chatRoomName").textContent=name;
    $("#messages").innerHTML=""; state.chat.filter(m=>m.roomId===currentRoom).forEach(appendMessage);
    setPage("chat"); toast("เข้าห้อง "+name+" แล้ว");
  }
  function renderGroups() {
    $("#groupsList").innerHTML=state.groups.map(g=>`<div class="group-card"><span class="pill">${g.isPrivate?"ส่วนตัว":"กลุ่ม"}</span><h3>${esc(g.name)}</h3><p>${esc(g.description||"อ่านหนังสือร่วมกัน")}</p><button class="secondary small-btn" data-enter="${g.id}">เข้าห้อง</button> <button class="text-btn" data-invite="${g.id}">เชิญเพื่อน</button></div>`).join("")||'<div class="empty">ยังไม่มีกลุ่ม ลองสร้างกลุ่มแรกของคุณ</div>';
    $$("[data-enter]").forEach(b=>b.onclick=()=>{const g=state.groups.find(x=>x.id===b.dataset.enter);joinRoom(g.id,g.name)});
    $$("[data-invite]").forEach(b=>b.onclick=()=>showInvite(b.dataset.invite));
  }
  function renderPresence(presence) {
    if(!presence)return;
    $("#liveStats").innerHTML=`<div class="live-stat"><strong>${presence.users.length}</strong><span>คนออนไลน์</span></div><div class="live-stat"><strong>${presence.rooms.length}</strong><span>ห้องที่มีคน</span></div><div class="live-stat"><strong>${presence.totalMinutes}</strong><span>นาทีสะสมในเซสชันที่ยังเปิดอยู่</span></div>`;
    $("#presenceList").innerHTML=presence.users.filter(u=>u.room===currentRoom||currentRoom==="lobby").map(u=>`<div class="item item-head"><div><b>● ${esc(u.nickname)} ${u.userId===userId?"(คุณ)":""}</b><p>${esc(u.room==="lobby"?"ห้องกลาง":(state.groups.find(g=>g.id===u.room)||{}).name||"ห้องอ่าน")}</p></div><span class="meta">${u.minutes} นาที</span></div>`).join("")||'<div class="empty">ยังไม่มีข้อมูลผู้ใช้ออนไลน์</div>';
  }
  $("#examForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);let questions=[];try{questions=f.get("questions").trim()?JSON.parse(f.get("questions")):[]}catch{toast("JSON ของข้อสอบไม่ถูกต้อง");return}try{await api("/api/exams",json({title:f.get("title"),subject:f.get("subject"),chapter:f.get("chapter"),description:f.get("description"),questions,createdBy:nickname}));e.currentTarget.reset();await refresh();toast("เพิ่มชุดข้อสอบแล้ว")}catch(err){toast(err.message)}});
  $("#examFilter").onchange=renderExams;
  function renderExams() {
    const filter=$("#examFilter").value;
    const exams=state.exams.filter(x=>!filter||x.subject===filter);
    $("#examList").innerHTML=exams.map(x=>`<div class="item"><div class="item-head"><div><h3>${esc(x.title)}</h3><p>${esc(x.subject)} · ${esc(x.chapter||"ไม่ระบุบท")}</p><div class="meta">${x.questions.length} ข้อ · ${esc(x.createdBy||"สมาชิก")} · ${dateFmt(x.createdAt)}</div></div><button class="primary small-btn" data-quiz="${x.id}">เริ่มทำ</button></div><p>${esc(x.description)}</p></div>`).join("")||'<div class="empty">ยังไม่มีชุดข้อสอบในหมวดนี้</div>';
    $$("[data-quiz]").forEach(b=>b.onclick=()=>startQuiz(b.dataset.quiz));
  }
  function startQuiz(examId) {
    activeQuiz=state.exams.find(x=>x.id===examId);quizAnswers={};if(!activeQuiz)return;
    $("#quizTitle").textContent=activeQuiz.title;$("#quizPanel").hidden=false;$("#quizBody").innerHTML=activeQuiz.questions.length?activeQuiz.questions.map((q,i)=>`<div class="item"><b>${i+1}. ${esc(q.question)}</b><div class="form top-gap">${q.choices.map((c,j)=>`<label class="check-label"><input type="radio" name="q${i}" value="${j}"> ${String.fromCharCode(65+j)}. ${esc(c)}</label>`).join("")}</div><div id="explain${i}" class="muted small" hidden></div></div>`).join("")+'<button class="primary top-gap" id="submitQuiz">ตรวจคำตอบ</button><div id="quizResult"></div>':'<div class="empty">ชุดนี้ยังไม่มีข้อสอบ โปรดเพิ่มคำถามในรูปแบบ JSON</div>';
    $("#quizPanel").scrollIntoView({behavior:"smooth"});
    const submit=$("#submitQuiz");if(submit)submit.onclick=async()=>{
      let correct=0;
      activeQuiz.questions.forEach((q,i)=>{const sel=$(`input[name="q${i}"]:checked`);const ans=sel?Number(sel.value):-1;if(ans===q.answer)correct++;const ex=$("#explain"+i);ex.hidden=false;ex.innerHTML=`เฉลย: <b>${String.fromCharCode(65+q.answer)}</b> ${esc(q.explanation||"")}`});
      $("#quizResult").innerHTML=`<div class="score-result"><strong>${correct}/${activeQuiz.questions.length}</strong><p>คะแนนชุดนี้ · ${Math.round(correct/Math.max(1,activeQuiz.questions.length)*100)}%</p></div>`;
      if(activeQuiz.questions.length) await api("/api/checkins",json({userId,subject:activeQuiz.subject,chapter:activeQuiz.chapter||activeQuiz.title,minutes:0,correct,total:activeQuiz.questions.length,note:"ทำชุดข้อสอบ: "+activeQuiz.title}));
      await refresh();
    };
  }
  $("#closeQuiz").onclick=()=>$("#quizPanel").hidden=true;
  $("#checkinForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);const body={userId,planId:f.get("planId"),subject:f.get("subject"),chapter:f.get("chapter"),minutes:f.get("minutes"),correct:f.get("correct"),total:f.get("total"),note:f.get("note")};if(Number(body.correct)>Number(body.total)){toast("จำนวนข้อถูกต้องต้องไม่มากกว่าจำนวนข้อทั้งหมด");return}try{await api("/api/checkins",json(body));e.currentTarget.reset();await refresh();toast("บันทึกเช็กอินแล้ว")}catch(err){toast(err.message)}});
  function renderProgress() {
    const mine=state.checkins.filter(c=>c.userId===userId);
    const mins=mine.reduce((a,c)=>a+c.minutes,0), correct=mine.reduce((a,c)=>a+c.correct,0), total=mine.reduce((a,c)=>a+c.total,0);
    $("#progressSummary").innerHTML=`<div class="summary-tile"><strong>${Math.floor(mins/60)}h ${mins%60}m</strong><span>เวลาอ่านที่บันทึก</span></div><div class="summary-tile"><strong>${total?Math.round(correct/total*100):0}%</strong><span>ความแม่นยำรวม</span></div><div class="summary-tile"><strong>${mine.length}</strong><span>เช็กอิน/ชุดฝึก</span></div>`;
    const by={};mine.forEach(c=>{const k=(c.subject||"อื่น ๆ")+" · "+(c.chapter||"ไม่ระบุบท");by[k]??={correct:0,total:0,minutes:0,count:0};by[k].correct+=c.correct;by[k].total+=c.total;by[k].minutes+=c.minutes;by[k].count++});
    const ranked=Object.entries(by).map(([name,x])=>({name,...x,rate:x.total?Math.round(x.correct/x.total*100):0})).sort((a,b)=>b.rate-a.rate);
    $("#weakStrong").innerHTML=ranked.length?`<div class="item"><b>จุดแข็งที่ทำได้ดี</b><p>${ranked.filter(x=>x.total&&x.rate>=80).map(x=>`${esc(x.name)} (${x.rate}%)`).join(", ")||"ยังไม่มีบทที่คะแนนถึง 80% — ฝึกเพิ่มแล้วระบบจะเห็นแนวโน้มชัดขึ้น"}</p></div><div class="item"><b>บทที่ควรทบทวน</b><p>${ranked.filter(x=>x.total&&x.rate<70).map(x=>`${esc(x.name)} (${x.rate}%)`).join(", ")||"ยังไม่พบจุดอ่อนชัดเจน หรือข้อมูลยังไม่พอ"}</p></div><p class="muted small">ประเมินจากข้อมูลที่บันทึกเท่านั้น ผลของบทที่มีข้อสอบน้อยอาจผันผวน ควรทำอย่างน้อย 10 ข้อต่อบท</p>`:'<div class="empty">บันทึกการอ่านหรือทำข้อสอบก่อน แล้วระบบจะแสดงจุดแข็ง–จุดที่ควรทบทวน</div>';
    $("#checkinList").innerHTML=mine.slice().reverse().slice(0,50).map(c=>`<div class="item item-head"><div><b>${esc(c.subject)} · ${esc(c.chapter)}</b><p>${esc(c.note||"เช็กอินการอ่าน")} · ${c.correct}/${c.total} ถูก (${c.total?Math.round(c.correct/c.total*100):0}%)</p><div class="meta">${new Date(c.createdAt).toLocaleString("th-TH")}</div></div><span class="pill">${c.minutes} นาที</span></div>`).join("")||'<div class="empty">ยังไม่มีประวัติ</div>';
  }
  $("#chatForm").addEventListener("submit",e=>{e.preventDefault();const inp=e.currentTarget.elements.message;const text=inp.value.trim();if(!text)return;if(!socket){toast("ยังเชื่อมต่อเซิร์ฟเวอร์ไม่ได้");return}socket.emit("chat:send",{text,roomId:currentRoom});inp.value=""});
  function appendMessage(m) {
    const box=$("#messages");const div=document.createElement("div");div.className="message"+(m.userId===userId?" mine":"");
    div.innerHTML=`<div class="sender">${esc(m.nickname||"ระบบ")}</div><p>${esc(m.text)}</p><time>${timeFmt(m.at||Date.now())}</time>`;
    box.appendChild(div);box.scrollTop=box.scrollHeight;
  }
  function renderChatHistory() { $("#messages").innerHTML="";state.chat.filter(m=>m.roomId===currentRoom).forEach(appendMessage); }
  $("#summaryForm").addEventListener("submit",async e=>{
    e.preventDefault();const f=new FormData(e.currentTarget);$("#summaryResult").textContent="กำลังอ่านไฟล์และสรุปด้วย AI… อาจใช้เวลาสักครู่";
    try{const r=await fetch("/api/ai/summarize",{method:"POST",body:f});const d=await r.json();if(!r.ok)throw new Error(d.error||"สรุปไม่สำเร็จ");summaryText=d.summary;$("#summaryResult").textContent=summaryText;toast("สรุปบทเรียนสำเร็จ")}
    catch(err){$("#summaryResult").textContent=err.message;toast(err.message)}
  });
  $("#copySummary").onclick=()=>{if(!summaryText)return toast("ยังไม่มีข้อความสรุป");navigator.clipboard.writeText(summaryText).then(()=>toast("คัดลอกสรุปแล้ว")).catch(()=>toast("คัดลอกไม่สำเร็จ"))};
  function renderResources() {
    const render=items=>items.map(x=>`<div class="item"><h3>${esc(x.title)}</h3><p>${esc(x.subject||"ไม่ระบุวิชา")} · ${esc(x.description||"")}</p><a class="resource-link" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer">เปิดทรัพยากร ↗</a></div>`).join("")||'<div class="empty">ยังไม่มีทรัพยากร</div>';
    $("#ebookList").innerHTML=render(state.resources);$("#simulationList").innerHTML=render(state.simulations);
  }
  $("#resourceForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);try{await api("/api/resources", {method:"POST",headers:{"Content-Type":"application/json","x-admin-passcode":f.get("adminPass")},body:JSON.stringify({title:f.get("title"),type:f.get("type"),subject:f.get("subject"),url:f.get("url"),description:f.get("description")})});e.currentTarget.reset();await refresh();toast("เพิ่มทรัพยากรแล้ว")}catch(err){toast(err.message)}});
  $("#uploadForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);const pass=f.get("adminPass");f.delete("adminPass");try{const r=await fetch("/api/admin/upload",{method:"POST",headers:{"x-admin-passcode":pass},body:f});const d=await r.json();if(!r.ok)throw new Error(d.error);e.currentTarget.reset();await refresh();toast("อัปโหลดไฟล์แล้ว")}catch(err){toast(err.message)}});
  $("#scoreModelForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);let subjects;try{subjects=JSON.parse(f.get("subjects"))}catch{toast("JSON วิชาและน้ำหนักไม่ถูกต้อง");return}try{await api("/api/score-models",{method:"POST",headers:{"Content-Type":"application/json","x-admin-passcode":f.get("adminPass")},body:JSON.stringify({name:f.get("name"),year:f.get("year"),faculty:f.get("faculty"),program:f.get("program"),referenceUrl:f.get("referenceUrl"),note:f.get("note"),subjects})});e.currentTarget.reset();await refresh();toast("บันทึกสูตรแล้ว")}catch(err){toast(err.message)}});
  function renderScoreModels() {
    const sel=$("#scoreModelSelect");const prev=sel.value;
    sel.innerHTML=state.scoreModels.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join("");
    if(prev&&state.scoreModels.some(x=>x.id===prev))sel.value=prev;
    renderScoreInputs();
  }
  $("#scoreModelSelect").onchange=renderScoreInputs;
  function renderScoreInputs() {
    const model=state.scoreModels.find(x=>x.id===$("#scoreModelSelect").value);
    if(!model){$("#scoreInputs").innerHTML='<p class="muted">ยังไม่มีสูตร</p>';return}
    $("#scoreInputs").innerHTML=`<p class="muted small">${esc(model.year)} · ${esc(model.faculty)} ${esc(model.program)}</p>${model.referenceUrl?`<p><a class="resource-link" target="_blank" rel="noopener" href="${esc(model.referenceUrl)}">เปิดประกาศอ้างอิง ↗</a></p>`:""}${model.note?`<p class="muted small">${esc(model.note)}</p>`:""}${model.subjects.map((s,i)=>`<label>${esc(s.name)} · น้ำหนัก ${s.weight}% (คะแนนเต็ม ${s.max})<input type="number" min="0" max="${s.max}" step="any" data-score="${i}" placeholder="คะแนนที่ได้"></label>`).join("")}`;
    $$("[data-score]").forEach(inp=>inp.oninput=calculateScore);calculateScore();
  }
  function calculateScore() {
    const model=state.scoreModels.find(x=>x.id===$("#scoreModelSelect").value);if(!model)return;
    const inputs=$$("[data-score]");let weighted=0,weightSum=0,valid=0;
    model.subjects.forEach((s,i)=>{const raw=inputs[i]?.value;if(raw!==""&&raw!==undefined){const score=Math.max(0,Math.min(Number(s.max),Number(raw)||0));weighted+=(score/Number(s.max))*Number(s.weight);valid++;}weightSum+=Number(s.weight)||0});
    const result=valid?weighted*(100/Math.max(1,weightSum)):"—";
    $("#scoreResult").innerHTML=`<strong>${valid?result.toFixed(2):"—"} / 100</strong><p>คะแนนถ่วงน้ำหนักจากวิชาที่กรอก ${valid}/${model.subjects.length} วิชา</p><p>น้ำหนักรวมสูตร: ${weightSum}%</p><p>เป็นการคำนวณตามค่าที่กรอก ไม่ใช่คะแนนตัดหรือการรับประกันผลการคัดเลือก</p>`;
  }
  init();
})();
